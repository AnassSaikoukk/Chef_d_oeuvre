# -*- coding: utf-8 -*-
"""
Created on Sun Jan 28 11:22:55 2018

@author: SAIKOUK
"""
import pickle
import os 
from operator import itemgetter
import pre_processing

import re
from gensim import models, corpora
from nltk import word_tokenize
from nltk.corpus import stopwords



lsi_fp = open('lsa_model.pkl', 'rb')
lsimodel = pickle.load(lsi_fp)  



def get_theme(doc):
    topics = "topic_1 topic_2 topic_3 \
    topic_4 topic_5 topic_6 topic_7 topic_8 topic_9   topic_10 topic_11 \
    topic_12 topic_13 topic_14 topic_15 topic_16 topic_17 topic_18 topic_19 \
    topic_20".split()
    
    theme = ""
    
    cleandoc = pre_processing.clean_doc(doc)
    doc_bow = lsimodel.id2word.doc2bow(cleandoc)
    doc_topics = lsimodel.get_topics()
    print(doc_topics)
    if doc_topics.all():
        doc_topics.sort(key = itemgetter(1), reverse=True)
        theme = topics[doc_topics[0][0]]
        if theme == "unknown":
            theme = topics[doc_topics[1][0]]
    else:
        theme = "unknown"
    return theme


theme = get_theme("Rencontre avec Dodo La Saumure : «Je ne connais pas #DSK, mais j'aurais aimé le rencontrer")   
print("topic:"+theme)
