import pre_processing 
#import plot_perplexity
from gensim import corpora, models
from gensim.models.ldamodel import LdaModel as Lda
from gensim.models.lsimodel import LsiModel as Lsi
import pickle

      
docs = pre_processing.read_csv('Tache2_Train.csv')

doc_clean = pre_processing.clean_corpus(docs)


dictionary = corpora.Dictionary(doc_clean)


dictionary.filter_extremes(no_below=4, no_above=0.6)


doc_term_matrix = [dictionary.doc2bow(doc) for doc in doc_clean]




ldamodel = Lda(doc_term_matrix, num_topics=20, id2word = dictionary, passes=100, iterations=500)

#plot_perplexity.plot_perplexity(ldamodel,dictionary,doc_term_matrix,2,10,2)

#Build the LSI model
lsamodel = models.LsiModel(doc_term_matrix, num_topics=20, id2word = dictionary)

#models.LsiModel(corpus=corpus, num_topics=NUM_TOPICS, id2word=dictionary)

ldafile = open('lda_model.pkl','wb')
lsafile = open('lsa_model.pkl','wb')
pickle.dump(ldamodel,ldafile)
pickle.dump(lsamodel,lsafile)
ldafile.close()
lsafile.close()

#Print all the topics of LDAMODEL
for topic in ldamodel.print_topics(num_topics=20, num_words=10):
    print(topic[0]+1, " ", topic[1],"\n")


#Print all the topics of LSAMODEL
print("Test ")
print("test")
for topic in lsamodel.print_topics(num_topics=20, num_words=10):
    print(topic[0]+1, " ", topic[1],"\n")

